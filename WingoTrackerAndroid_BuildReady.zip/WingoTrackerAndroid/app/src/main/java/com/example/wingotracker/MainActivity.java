package com.example.wingotracker;

import android.app.Activity;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(16,20,38), card = Color.rgb(29,35,59);
    private TextView timerText, statusText, countText, historyText, bigCount, smallCount;
    private EditText numberInput;
    private CountDownTimer timer;
    private long remaining = 60000;
    private boolean running = false;
    private JSONArray history = new JSONArray();
    private int big = 0, small = 0;
    private android.content.SharedPreferences prefs;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("tracker", MODE_PRIVATE);
        loadHistory();
        buildUi();
        renderHistory();
        updateTimer();
    }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius);
        return d;
    }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size);
        t.setTextColor(color); t.setGravity(Gravity.CENTER);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private Button button(String label, int color) {
        Button b = new Button(this); b.setText(label); b.setTextColor(Color.WHITE);
        b.setAllCaps(false); b.setTextSize(15); b.setBackground(shape(color, 24));
        return b;
    }

    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(18, 12, 18, 12); return l;
    }

    private LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w, h);
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this); scroll.setBackgroundColor(bg);
        LinearLayout root = column(); root.setPadding(18, 18, 18, 28);
        scroll.addView(root); setContentView(scroll);

        TextView title = text("WINGO TRACKER", 25, Color.WHITE, true);
        root.addView(title, lp(-1, 54));
        TextView subtitle = text("60-second timer • manual result history", 13, 0xFFB8C0DA, false);
        root.addView(subtitle, lp(-1, 30));

        LinearLayout timerCard = column(); timerCard.setGravity(Gravity.CENTER);
        timerCard.setBackground(shape(card, 24));
        LinearLayout.LayoutParams cp = lp(-1, -2); cp.setMargins(0, 12, 0, 14);
        root.addView(timerCard, cp);
        timerCard.addView(text("NEXT ROUND TIMER", 13, 0xFFB8C0DA, true), lp(-1, 30));
        timerText = text("01:00", 52, Color.WHITE, true);
        timerCard.addView(timerText, lp(-1, 82));
        statusText = text("Ready", 14, 0xFF72E6B4, false);
        timerCard.addView(statusText, lp(-1, 28));

        LinearLayout timerButtons = new LinearLayout(this); timerButtons.setGravity(Gravity.CENTER);
        Button start = button("Start / Resume", 0xFF6546D7);
        Button pause = button("Pause", 0xFF46506F);
        Button reset = button("Reset", 0xFF3A4260);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, 52, 1);
        bp.setMargins(4, 8, 4, 8);
        timerButtons.addView(start, bp); timerButtons.addView(pause, bp); timerButtons.addView(reset, bp);
        timerCard.addView(timerButtons, lp(-1, 64));
        start.setOnClickListener(v -> startTimer());
        pause.setOnClickListener(v -> pauseTimer());
        reset.setOnClickListener(v -> { pauseTimer(); remaining = 60000; updateTimer(); statusText.setText("Ready"); });

        TextView section = text("MANUAL RESULT ENTRY", 17, Color.WHITE, true);
        section.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(section, lp(-1, 44));
        TextView help = text("Enter a result number from 0 to 9. This only records results; it does not predict future outcomes.", 13, 0xFFB8C0DA, false);
        root.addView(help, lp(-1, 54));

        LinearLayout entryCard = column(); entryCard.setBackground(shape(card, 20));
        root.addView(entryCard, cp);
        numberInput = new EditText(this); numberInput.setSingleLine(true);
        numberInput.setHint("Result number (0–9)"); numberInput.setTextColor(Color.WHITE);
        numberInput.setHintTextColor(0xFF8F98B8); numberInput.setInputType(2);
        numberInput.setPadding(16, 8, 16, 8); numberInput.setBackground(shape(0xFF222A46, 14));
        entryCard.addView(numberInput, lp(-1, 52));
        Button add = button("Add Result", 0xFF168C70);
        LinearLayout.LayoutParams addp = lp(-1, 50); addp.setMargins(0, 12, 0, 2);
        entryCard.addView(add, addp); add.setOnClickListener(v -> addResult());

        TextView statsTitle = text("BIG / SMALL SUMMARY", 17, Color.WHITE, true);
        statsTitle.setGravity(Gravity.CENTER_VERTICAL); root.addView(statsTitle, lp(-1, 48));
        LinearLayout stats = new LinearLayout(this);
        LinearLayout bigCard = column(), smallCard = column();
        bigCard.setGravity(Gravity.CENTER); smallCard.setGravity(Gravity.CENTER);
        bigCard.setBackground(shape(0xFF245B48, 20)); smallCard.setBackground(shape(0xFF5A3150, 20));
        LinearLayout.LayoutParams statp = new LinearLayout.LayoutParams(0, 96, 1);
        statp.setMargins(4, 4, 4, 4); stats.addView(bigCard, statp); stats.addView(smallCard, statp);
        bigCount = text("0", 28, Color.WHITE, true); smallCount = text("0", 28, Color.WHITE, true);
        bigCard.addView(text("BIG (5–9)", 13, Color.WHITE, true)); bigCard.addView(bigCount);
        smallCard.addView(text("SMALL (0–4)", 13, Color.WHITE, true)); smallCard.addView(smallCount);
        root.addView(stats, lp(-1, 108));

        LinearLayout historyHeader = new LinearLayout(this);
        historyHeader.setGravity(Gravity.CENTER_VERTICAL);
        TextView ht = text("RESULT HISTORY", 17, Color.WHITE, true);
        ht.setGravity(Gravity.CENTER_VERTICAL); historyHeader.addView(ht, new LinearLayout.LayoutParams(0, 48, 1));
        Button clear = button("Clear", 0xFF46506F); historyHeader.addView(clear, lp(88, 42));
        clear.setOnClickListener(v -> clearHistory());
        root.addView(historyHeader, lp(-1, 48));
        historyText = text("No results recorded yet.", 14, 0xFFE2E6F5, false);
        historyText.setGravity(Gravity.TOP | Gravity.LEFT); historyText.setPadding(14, 14, 14, 14);
        historyText.setBackground(shape(card, 18)); root.addView(historyText, lp(-1, -2));

        TextView note = text("For tracking only. Random game outcomes cannot be reliably predicted.", 12, 0xFF929BB9, false);
        root.addView(note, lp(-1, 52));
    }

    private void startTimer() {
        if (running) return;
        if (remaining <= 0) remaining = 60000;
        running = true; statusText.setText("Running");
        timer = new CountDownTimer(remaining, 100) {
            public void onTick(long millis) { remaining = millis; updateTimer(); }
            public void onFinish() {
                remaining = 0; running = false; updateTimer();
                statusText.setText("Round timer finished");
            }
        }.start();
    }

    private void pauseTimer() {
        if (timer != null) timer.cancel();
        running = false;
        if (statusText != null && remaining > 0) statusText.setText("Paused");
    }

    private void updateTimer() {
        if (timerText != null) {
            long secs = Math.max(0, remaining / 1000);
            timerText.setText(String.format(Locale.getDefault(), "%02d:%02d", secs / 60, secs % 60));
        }
    }

    private void addResult() {
        String value = numberInput.getText().toString().trim();
        if (value.isEmpty()) { numberInput.setError("Enter a number from 0 to 9"); return; }
        int n;
        try { n = Integer.parseInt(value); } catch (Exception e) { numberInput.setError("Invalid number"); return; }
        if (n < 0 || n > 9) { numberInput.setError("Use 0 to 9 only"); return; }
        try {
            JSONObject item = new JSONObject();
            item.put("number", n);
            item.put("type", n >= 5 ? "BIG" : "SMALL");
            item.put("time", System.currentTimeMillis());
            history.put(item);
            saveHistory(); renderHistory(); numberInput.setText("");
        } catch (Exception ignored) {}
    }

    private void loadHistory() {
        try { history = new JSONArray(prefs.getString("history", "[]")); }
        catch (Exception e) { history = new JSONArray(); }
    }

    private void saveHistory() {
        prefs.edit().putString("history", history.toString()).apply();
    }

    private void renderHistory() {
        big = 0; small = 0;
        StringBuilder out = new StringBuilder();
        for (int i = history.length() - 1; i >= 0; i--) {
            JSONObject item = history.optJSONObject(i);
            if (item == null) continue;
            int n = item.optInt("number", -1);
            String type = item.optString("type", n >= 5 ? "BIG" : "SMALL");
            if (type.equals("BIG")) big++; else small++;
            out.append(String.format(Locale.getDefault(), "%02d.  Number: %d   •   %s\n",
                    history.length() - i, n, type));
        }
        if (history.length() == 0) out.append("No results recorded yet.");
        historyText.setText(out.toString());
        bigCount.setText(String.valueOf(big)); smallCount.setText(String.valueOf(small));
    }

    private void clearHistory() {
        history = new JSONArray(); saveHistory(); renderHistory();
    }

    @Override protected void onDestroy() {
        if (timer != null) timer.cancel();
        super.onDestroy();
    }
}
