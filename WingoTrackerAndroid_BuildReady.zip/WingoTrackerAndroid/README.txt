Wingo Tracker Android project

Features:
- 60-second timer with start/resume, pause, reset
- Manual entry of result numbers 0-9
- Big/Small classification: 5-9 = BIG, 0-4 = SMALL
- Saved result history and totals

This is a local tracking utility, not a prediction tool. It does not connect to any betting website or automate bets.

BUILD APK ONLINE (no computer build setup required):
1. Create/sign in to a GitHub account.
2. Create a NEW public or private repository named WingoTracker.
3. Upload the contents of this ZIP (the WingoTracker project folder contents) to the repository root. Make sure the hidden .github/workflows/build-apk.yml file is uploaded too.
4. Open the repository's Actions tab.
5. Select "Build Wingo Tracker APK" and click "Run workflow" (or wait for the first push build).
6. Wait until the workflow succeeds, open that completed run, and download the "WingoTracker-debug-apk" artifact.
7. Extract the downloaded artifact ZIP to get app-debug.apk, then open it on your Android phone and allow installation if Android asks.

Build requirements: Android SDK platform 35 and Gradle 8.9; automated workflow configures these for you.
